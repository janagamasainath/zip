package com.example.orderservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.orderservice.common.Payment;
import com.example.orderservice.common.TransactionRequest;
import com.example.orderservice.common.TransactionResponse;
import com.example.orderservice.entity.Order;
import com.example.orderservice.repo.OrderRepo;

@Service 
public class OrderService {

	@Autowired
private OrderRepo orderRepo;

  @Autowired 
  private RestTemplate restTemplate;
 
	
	public TransactionResponse bookOrder(TransactionRequest request) {
		
		//String message="";
		Order order = request.getOrder();
		Payment payment=request.getPayment();
		payment.setOrderId(order.getOrderId());
		payment.setPrice(order.getPrice());
		
		//logic to do rest call
		 Payment paymentResponse = restTemplate.postForObject("http://PAYMENT-SERVICE/payment/dopayment", payment, Payment.class);
		
		// message=	payment.getPaymetStatus().equals("success")?"order book success and payment received":"order cancel due to timeout";
		// message=	payment.getPaymetStatus().equals("success")?"oreder successfully":"fail due to time out";
		 
		 orderRepo.save(order);
	return new TransactionResponse(order, paymentResponse.getTransactionId(), paymentResponse.getPrice());
		
	}
}
