
package com.example.orderservice.common;

public class Payment {

	private int paymentId;

	private String paymetStatus;

	private String transactionId;

	private int orderId;

	private double price;

	public Payment(int paymentId, String paymetStatus, String transactionId, int orderId, double price) {
		super();
		this.paymentId = paymentId;
		this.paymetStatus = paymetStatus;
		this.transactionId = transactionId;
		this.orderId = orderId;
		this.price = price;
	}

	public Payment() {
		// TODO Auto-generated constructor stub
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymetStatus() {
		return paymetStatus;
	}

	public void setPaymetStatus(String paymetStatus) {
		this.paymetStatus = paymetStatus;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
