
package com.example.orderservice.common;

import com.example.orderservice.entity.Order;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

public class TransactionResponse {

	
	private Order order;
	private String transactionId;
	private double price;
	//private String message;
	public TransactionResponse(Order order, String transactionId, double price) {
		super();
		this.order = order;
		this.transactionId = transactionId;
		this.price = price;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public TransactionResponse() {
		// TODO Auto-generated constructor stub
	}
	 }
